const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require("path");
const axios = require('axios');
const https = require("https");

const CONFIG = {
    botToken: "8416588824:AAEzBwsO5Pen1QDLiGdYgzsEo9RMiJbS_PY",
    github: {
        token: "YOUR_GITHUB_TOKEN",
        repoOwner: "yourusername",
        repoName: "your-repo",
        filePath: "tokens.json"
    },
    dataDir: path.join(__dirname, "☇ Confidential"),
    dataFiles: {
        highowner: "highowner.json",
        owner: "owners.json",
        admin: "admin.json",
        reseller: "resellers.json",
        moderator: "mods.json",
        ceo: "ceo.json",
        blocklist: "blocklist.json"
    }
};

function ensureDirectory() {
    if (!fs.existsSync(CONFIG.dataDir)) {
        fs.mkdirSync(CONFIG.dataDir, { recursive: true });
    }
}

function loadJSON(fileName, fallback = {}) {
    const filePath = path.join(CONFIG.dataDir, fileName);
    try {
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch {
        fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2));
        return fallback;
    }
}

function saveJSON(fileName, data) {
    const filePath = path.join(CONFIG.dataDir, fileName);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

ensureDirectory();
const data = {
    highowner: loadJSON(CONFIG.dataFiles.highowner, { highowners: [] }),
    owner: loadJSON(CONFIG.dataFiles.owner, { owners: [] }),
    admin: loadJSON(CONFIG.dataFiles.admin, { admins: [] }),
    reseller: loadJSON(CONFIG.dataFiles.reseller, { resellers: [] }),
    moderator: loadJSON(CONFIG.dataFiles.moderator, { moderators: [] }),
    ceo: loadJSON(CONFIG.dataFiles.ceo, { ceos: [] }),
    blocklist: loadJSON(CONFIG.dataFiles.blocklist, [])
};

const Roles = {
    isHighOwner(userId) {
        return data.highowner.highowners.includes(userId);
    },

    isOwner(userId) {
        return data.owner.owners.includes(userId);
    },
    
    isAdmin(userId) {
        return data.admin.admins.includes(userId) || this.isOwner(userId) || this.isHighOwner(userId);
    },
    
    isModerator(userId) {
        return data.moderator.moderators.includes(userId);
    },
    
    isCeo(userId) {
        return data.ceo.ceos.includes(userId);
    },
    
    isReseller(userId) {
        return data.reseller.resellers.includes(userId);
    },
    
    hasAccess(userId) {
        return this.isHighOwner(userId) || this.isOwner(userId) || 
               this.isAdmin(userId) || this.isModerator(userId) || 
               this.isCeo(userId) || this.isReseller(userId);
    },
    
    getUserRole(userId) {
        if (this.isHighOwner(userId)) return "HIGH OWNER";
        if (this.isOwner(userId)) return "OWNER";
        if (this.isAdmin(userId)) return "ADMIN";
        if (this.isModerator(userId)) return "MODERATOR";
        if (this.isCeo(userId)) return "CEO";
        if (this.isReseller(userId)) return "RESELLER";
        return "USER";
    },
    
    getUserRoleLevel(userId) {
        if (this.isHighOwner(userId)) return 100;
        if (this.isOwner(userId)) return 90;
        if (this.isAdmin(userId)) return 80;
        if (this.isModerator(userId)) return 70;
        if (this.isCeo(userId)) return 60;
        if (this.isReseller(userId)) return 50;
        return 0;
    }
};

async function githubRequest(options, body = null) {
    return new Promise((resolve, reject) => {
        const reqOptions = {
            ...options,
            headers: {
                'Authorization': `token ${CONFIG.github.token}`,
                'User-Agent': 'Telegram-Bot',
                'Content-Type': 'application/json'
            }
        };
        
        const req = https.request(reqOptions, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch {
                    resolve(data);
                }
            });
        });
        
        req.on('error', reject);
        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

async function fetchTokens() {
    try {
        const options = {
            hostname: 'api.github.com',
            path: `/repos/${CONFIG.github.repoOwner}/${CONFIG.github.repoName}/contents/${CONFIG.github.filePath}`,
            method: 'GET'
        };
        
        const response = await githubRequest(options);
        if (response.content) {
            const content = Buffer.from(response.content, 'base64').toString('utf8');
            return JSON.parse(content);
        }
        return [];
    } catch {
        return [];
    }
}

async function updateTokens(tokens) {
    try {
        const existing = await fetchTokens();
        const content = Buffer.from(JSON.stringify(tokens, null, 2)).toString('base64');
        
        const options = {
            hostname: 'api.github.com',
            path: `/repos/${CONFIG.github.repoOwner}/${CONFIG.github.repoName}/contents/${CONFIG.github.filePath}`,
            method: 'PUT'
        };
        
        const body = {
            message: 'Update tokens via Telegram Bot',
            content: content,
            sha: existing.sha || null
        };
        
        await githubRequest(options, body);
        return true;
    } catch (error) {
        console.error('GitHub update error:', error);
        return false;
    }
}

const bot = new TelegramBot(CONFIG.botToken, { polling: true });

async function getTarget(msg) {
    if (msg.reply_to_message) return msg.reply_to_message.from;
    
    if (msg.entities) {
        for (const e of msg.entities) {
            if (e.type === "mention") {
                const username = msg.text.substring(e.offset + 1, e.offset + e.length);
                try {
                    const member = await bot.getChatMember(msg.chat.id, username);
                    return member.user;
                } catch {
                    return null;
                }
            }
        }
    }
    
    return msg.from;
}

function shouldIgnoreMessage(msg) {
    return msg.chat.type === 'private';
}

function sendAccessDenied(chatId, userId = null) {
    const message = userId ? 
        `❌ @${userId} tidak memiliki akses!` : 
        "❌ Anda tidak memiliki akses!";
    bot.sendMessage(chatId, message);
}

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const version = "1.0";
    const name = "DATABASE";

    const caption = `<blockquote>(⸙) ──── DATABASE ──── (⸙)

<tg-emoji emoji-id="4974606326828107003">✨</tg-emoji> FITURE GROUP
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /ban
╰ ʙᴀɴɴᴇᴅ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /unban
╰ ᴜɴʙᴀɴ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴏ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /open 
╰  ᴍᴇᴍʙᴜᴋᴀ ᴄʜᴀᴛ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /close 
╰  ᴍᴇɴᴜᴛᴜᴘ ᴄʜᴀᴛ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /mute
╰ ᴍᴜᴛᴇ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /unmute
╰ ʙᴜᴋᴀ ᴍᴜᴛᴇ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /antilink
╰ ᴀɴᴛɪʟɪɴᴋ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /antipromosi
╰ ᴀɴᴛɪ ᴘʀᴏᴍᴏsɪ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji>  /addantipromosi
╰ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ʟɪsᴛ ʙʟᴏᴄᴋʟɪsᴛ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /listblocklist
╰ ᴍᴇʟɪʜᴀᴛ ᴅᴀғᴛᴀʀ ʙʟᴏᴄᴋʟɪsᴛ</blockquote>`;

    const keyboard = [
        [{ text: "ᴅᴀᴛᴀʙᴀsᴇ ᴍᴇɴᴜ", callback_data: "token_menu", style: "primary", icon_custom_emoji_id: "4972400100912399455" }],
        [{ text: "ᴛᴏᴏʟs ᴍᴇɴᴜ", callback_data: "tools_menu", style: "danger", icon_custom_emoji_id: "4972233103993996390" }],
        [{ text: "ᴅᴇᴠᴇʟᴏᴘᴇʀ", url: "https://t.me/ungke", style: "success", icon_custom_emoji_id: "4972406526183474660" }],
    ];

    const localPhotoPath = path.join(__dirname, "Media", "Lolipop.jpg");
    let photoPath;
    
    if (fs.existsSync(localPhotoPath)) {
        photoPath = localPhotoPath;
    } else {
        photoPath = "https://l.top4top.io/p_3855f3alr1.jpg";
    }

    bot.sendPhoto(chatId, photoPath, {
        caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard },
        reply_to_message_id: msg.message_id
    });
});
bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const userId = query.from.id;
    const data = query.data;
    const version = "2.0";
    const name = "MD INVISO";

    const editMenu = async (caption, keyboard) => {
        try {
            await bot.editMessageCaption(caption, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: keyboard },
            });
        } catch (err) {
            console.error("Edit menu error:", err);
            await bot.answerCallbackQuery(query.id, { 
                text: "☇ Menu ini sudah aktif.", 
                show_alert: true 
            });
        }
    };

    try {
        if (data.startsWith('addrole_')) {
            const [, action, targetId] = data.split('_');

            if (!Roles.isHighOwner(userId)) {
                return bot.answerCallbackQuery(query.id, {
                    text: "❌ Hanya HIGH OWNER yang dapat melakukan ini!",
                    show_alert: true
                });
            }
            
            if (action === 'cancel') {
                bot.deleteMessage(chatId, messageId);
                return bot.answerCallbackQuery(query.id, { 
                    text: "✅ Dibatalkan!", 
                    show_alert: true 
                });
            }
            
            let success = false;
            let roleName = "";
            let targetUserId = parseInt(targetId);
            
            switch(action) {
                case 'highowner':
                    if (!data.highowner.highowners.includes(targetUserId)) {
                        data.highowner.highowners.push(targetUserId);
                        saveJSON(CONFIG.dataFiles.highowner, data.highowner);
                        success = true;
                        roleName = "HIGH OWNER";
                    }
                    break;
                    
                case 'owner':
                    if (!data.owner.owners.includes(targetUserId)) {
                        data.owner.owners.push(targetUserId);
                        saveJSON(CONFIG.dataFiles.owner, data.owner);
                        success = true;
                        roleName = "OWNER";
                    }
                    break;
                    
                case 'admin':
                    if (!data.admin.admins.includes(targetUserId)) {
                        data.admin.admins.push(targetUserId);
                        saveJSON(CONFIG.dataFiles.admin, data.admin);
                        success = true;
                        roleName = "ADMIN";
                    }
                    break;
                    
                case 'reseller':
                    if (!data.reseller.resellers.includes(targetUserId)) {
                        data.reseller.resellers.push(targetUserId);
                        saveJSON(CONFIG.dataFiles.reseller, data.reseller);
                        success = true;
                        roleName = "RESELLER";
                    }
                    break;
                    
                case 'moderator':
                    if (!data.moderator.moderators.includes(targetUserId)) {
                        data.moderator.moderators.push(targetUserId);
                        saveJSON(CONFIG.dataFiles.moderator, data.moderator);
                        success = true;
                        roleName = "MODERATOR";
                    }
                    break;
                    
                case 'ceo':
                    if (!data.ceo.ceos.includes(targetUserId)) {
                        data.ceo.ceos.push(targetUserId);
                        saveJSON(CONFIG.dataFiles.ceo, data.ceo);
                        success = true;
                        roleName = "CEO";
                    }
                    break;
            }
            
            if (success) {
                bot.editMessageText(`✅ Berhasil menambahkan sebagai ${roleName}!`, {
                    chat_id: chatId,
                    message_id: messageId
                });
            } else {
                bot.answerCallbackQuery(query.id, {
                    text: "⚠️ Pengguna sudah memiliki role tersebut!",
                    show_alert: true
                });
            }
            
            return bot.answerCallbackQuery(query.id);
        }

        switch (query.data) {
            case "token_menu": {
                const caption = `<blockquote>(⸙) ──── DATABASE

ⵌ ADDTOKEN MENU
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /addtoken
╰ ᴍᴇɴᴀᴍʙᴀʜ ᴛᴏᴋᴇɴ ᴋᴇ ɢɪᴛʜᴜʙ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /deltoken
╰ ᴍᴇɴɢʜᴀᴘᴜs ᴛᴏᴋᴇɴ ᴋᴇ ɢɪᴛʜᴜʙ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji> /adduser
╰  ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ᴀᴄᴄᴇs ᴜsᴇʀ
<tg-emoji emoji-id="5972072533833289156">✨</tg-emoji>  /listtoken
╰  ᴍᴇʟɪʜᴀᴛ ᴅᴀғᴛᴀʀ ᴛᴏᴋᴇɴ sᴇɴsᴏʀ</blockquote>`;

                const keyboard = [
                    [{ text: "ʙᴀᴄᴋ", callback_data: "start_menu", style: "danger" }]
                ];
                await editMenu(caption, keyboard);
                break;
            }
            
            case "tools_menu": {
        const caption = `<blockquote><tg-emoji emoji-id="5972072533833289156">✨</tg-emoji>RANDOM TOOLS
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /ssip
╰ ɢᴇɴᴇʀᴀᴛᴇ ss ɪᴘʜᴏɴᴇ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /tiktokdl
╰ ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ ᴛᴀɴᴘᴀ ᴡᴀᴛᴇʀᴍᴀʀᴋ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /tiktoksearch
╰ sᴇᴀʀᴄʜɪɴɢ ᴠɪᴅᴇᴏ ᴛɪᴋᴛᴏᴋ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /bokep
╰ sᴇᴀʀᴄʜɪɴɢ ʙᴏᴋᴇᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /uploadgithub
╰ ᴜᴘʟᴏᴀᴅ ɪᴍᴀɢᴇ ᴍᴇɴᴊᴀᴅɪ ᴜʀʟ ɢɪᴛʜᴜʙ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /ipinfo
╰ ᴛʀᴀᴄᴋɪɴɢ ɪɴғᴏʀᴍᴀsɪ ɪᴘ ʏᴀɴɢ ᴅɪ ᴅᴀᴘᴀᴛ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /chatai
╰ ᴄʜᴀᴛ ᴅᴇɴɢᴀɴ ᴀɪ ᴘɪɴᴛᴀʀ</blockquote>`;

        const keyboard = [
          [{ text: "ʙᴀᴄᴋ", callback_data: "start_menu", style: "primary" }]
        ];
        await editMenu(caption, keyboard);
        break;
      }

            case "start_menu": {
                const caption = `<blockquote><tg-emoji emoji-id="4974606326828107003">✨</tg-emoji>FITURE GROUP
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /ban
╰ ʙᴀɴɴᴇᴅ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /unban
╰ ᴜɴʙᴀɴ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴏ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /open 
╰  ᴍᴇᴍʙᴜᴋᴀ ᴄʜᴀᴛ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /close 
╰  ᴍᴇɴᴜᴛᴜᴘ ᴄʜᴀᴛ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /mute
╰ ᴍᴜᴛᴇ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /unmute
╰ ʙᴜᴋᴀ ᴍᴜᴛᴇ ᴜsᴇʀ ᴅᴀʀɪ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /antilink
╰ ᴀɴᴛɪʟɪɴᴋ ɢʀᴏᴜᴘ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /antipromosi
╰ ᴀɴᴛɪ ᴘʀᴏᴍᴏsɪ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji>  /addantipromosi
╰ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ʟɪsᴛ ʙʟᴏᴄᴋʟɪsᴛ
<tg-emoji emoji-id="4974280407529818183">✨</tg-emoji> /listblocklist
╰ ᴍᴇʟɪʜᴀᴛ ᴅᴀғᴛᴀʀ ʙʟᴏᴄᴋʟɪsᴛ</blockquote>`;

                const keyboard = [
                      [{ text: "ᴅᴀᴛᴀʙᴀsᴇ ᴍᴇɴᴜ", callback_data: "token_menu", style: "primary", icon_custom_emoji_id: "4972400100912399455" }],
                      [{ text: "ᴛᴏᴏʟs ᴍᴇɴᴜ", callback_data: "tools_menu", style: "danger", icon_custom_emoji_id: "4972233103993996390" }],
                      [{ text: "ᴅᴇᴠᴇʟᴏᴘᴇʀ", url: "https://t.me/ungke", style: "success", icon_custom_emoji_id: "4972406526183474660" }],
                ];
                await editMenu(caption, keyboard);
                break;
            }

            default:
                await bot.answerCallbackQuery(query.id, {
                    text: "☇ Unknown Action",
                    show_alert: true,
                });
                break;
        }

        await bot.answerCallbackQuery(query.id);
    } catch (error) {
        console.error("Callback error:", error);
        try {
            await bot.answerCallbackQuery(query.id, {
                text: "☇ Terjadi kesalahan.",
                show_alert: true,
            });
        } catch {}
    }
});

bot.onText(/\/adduser/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (shouldIgnoreMessage(msg)) {
        return bot.sendMessage(chatId, "😡 Command ini hanya untuk grup!");
    }

    if (!Roles.isHighOwner(userId)) {
        return sendAccessDenied(chatId, msg.from.username);
    }
    
    const target = await getTarget(msg);
    if (!target) {
        return bot.sendMessage(chatId, "❌ Balas pesan pengguna yang ingin ditambahkan!");
    }
    
    const currentRole = Roles.getUserRole(target.id);
    if (currentRole !== "USER") {
        return bot.sendMessage(chatId, `⚠️ @${target.username} sudah memiliki role: ${currentRole}`);
    }

    bot.sendMessage(chatId, `Pilih role untuk @${target.username}:`, {
        reply_markup: {
            inline_keyboard: [
                [{ text: "HIGH OWNER", callback_data: `addrole_highowner_${target.id}` }],
                [{ text: "OWNER", callback_data: `addrole_owner_${target.id}` }],
                [{ text: "ADMIN", callback_data: `addrole_admin_${target.id}` }],
                [{ text: "RESELLER", callback_data: `addrole_reseller_${target.id}` }],
                [{ text: "MODERATOR", callback_data: `addrole_moderator_${target.id}` }],
                [{ text: "CEO", callback_data: `addrole_ceo_${target.id}` }],
                [{ text: "❌ BATALKAN", callback_data: `addrole_cancel_${target.id}` }]
            ]
        }
    });
});

bot.onText(/\/addtoken (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const newToken = match[1].trim();
    
    if (shouldIgnoreMessage(msg)) {
        return bot.sendMessage(chatId, "😡 Command ini hanya untuk grup!");
    }
    
    if (!Roles.hasAccess(userId)) {
        return sendAccessDenied(chatId, msg.from.username);
    }
    
    const tokens = await fetchTokens();
    if (tokens.includes(newToken)) {
        return bot.sendMessage(chatId, "⸙ Token sudah ada!");
    }
    
    tokens.push(newToken);
    const success = await updateTokens(tokens);
    
    if (success) {
        bot.sendMessage(chatId, "✅ Token berhasil ditambahkan ke GitHub!");
    } else {
        bot.sendMessage(chatId, "❌ Gagal menambahkan token! Periksa konfigurasi GitHub.");
    }
});

bot.onText(/\/listtoken/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (shouldIgnoreMessage(msg)) return;
    
    if (!Roles.isHighOwner(userId)) {
        return sendAccessDenied(chatId, msg.from.username);
    }
    
    const tokens = await fetchTokens();
    if (tokens.length === 0) {
        return bot.sendMessage(chatId, "ⵌ Tidak ada token tersimpan.");
    }
    
    const tokenList = tokens.map((t, i) => `${i + 1}. ${t.slice(0, 3)}***${t.slice(-3)}`).join("\n");
    bot.sendMessage(chatId, `⸙ **Daftar Token**\n\`\`\`${tokenList}\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/deltoken (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const tokenToRemove = match[1].trim();
    
    if (shouldIgnoreMessage(msg)) return;
    
    if (!Roles.hasAccess(userId)) {
        return sendAccessDenied(chatId, msg.from.username);
    }
    
    let tokens = await fetchTokens();
    if (!tokens.includes(tokenToRemove)) {
        return bot.sendMessage(chatId, "⸙ Token tidak ditemukan!");
    }
    
    tokens = tokens.filter(token => token !== tokenToRemove);
    const success = await updateTokens(tokens);
    
    if (success) {
        bot.sendMessage(chatId, "✅ Token berhasil dihapus!");
    } else {
        bot.sendMessage(chatId, "❌ Gagal menghapus token!");
    }
});

let antiLink = {};
let antiPromo = {};
let linkCount = {};

bot.onText(/\/antilink (.+)/, (msg, match) => {
    if (!Roles.isOwner(msg.from.id) && !Roles.isHighOwner(msg.from.id)) {
        return sendAccessDenied(msg.chat.id, msg.from.username);
    }
    
    antiLink[msg.chat.id] = match[1] === "on";
    bot.sendMessage(msg.chat.id, `Anti-Link: ${match[1]}`);
});

bot.onText(/\/antipromosi (.+)/, (msg, match) => {
    if (!Roles.isOwner(msg.from.id) && !Roles.isHighOwner(msg.from.id)) {
        return sendAccessDenied(msg.chat.id, msg.from.username);
    }
    
    antiPromo[msg.chat.id] = match[1] === "on";
    bot.sendMessage(msg.chat.id, `Anti-Promosi: ${match[1]}`);
});

bot.onText(/\/addantipromosi (.+)/, (msg, match) => {
    if (!Roles.isOwner(msg.from.id) && !Roles.isHighOwner(msg.from.id)) {
        return sendAccessDenied(msg.chat.id, msg.from.username);
    }
    
    const word = match[1].toLowerCase();
    data.blocklist.push(word);
    saveJSON(CONFIG.dataFiles.blocklist, data.blocklist);
    
    bot.sendMessage(msg.chat.id, `(⸙) Kata "${word}" ditambahkan ke blocklist.`);
});

bot.onText(/\/listblocklist/, (msg) => {
    if (!Roles.isOwner(msg.from.id) && !Roles.isHighOwner(msg.from.id)) {
        return sendAccessDenied(msg.chat.id, msg.from.username);
    }
    
    const list = data.blocklist.map((w, i) => `${i + 1}. ${w}`).join("\n");
    bot.sendMessage(msg.chat.id, `🐼 BLOCKLIST\n\n${list}`);
});

const linkRegex = /(https?|www\.|t\.me|wa\.me|\.com|\.net|discord\.gg)/i;

bot.on("message", (msg) => {
    if (!msg.text || shouldIgnoreMessage(msg)) return;
    
    const text = msg.text.toLowerCase().replace(/\s+/g, "");
    const chatId = msg.chat.id;
    
    if (antiPromo[chatId]) {
        for (const w of data.blocklist) {
            if (text.includes(w)) {
                bot.deleteMessage(chatId, msg.message_id);
                return bot.sendMessage(chatId, `(⸙) Promosi Terdeteksi — dihapus.`);
            }
        }
    }
    
    if (antiLink[chatId] && linkRegex.test(text)) {
        bot.deleteMessage(chatId, msg.message_id);
        
        const id = msg.from.id;
        linkCount[id] = (linkCount[id] || 0) + 1;
        
        if (linkCount[id] >= 3) {
            bot.restrictChatMember(chatId, id, { can_send_messages: false });
            return bot.sendMessage(chatId, `(⸙) @${msg.from.username} auto mute (3x link)`);
        }
        
        return bot.sendMessage(chatId, `⚠ Jangan kirim link! (${linkCount[id]}/3)`);
    }
});

const groupCommands = ['/ban', '/unban', '/mute', '/unmute', '/open', '/close'];
groupCommands.forEach(cmd => {
    bot.onText(new RegExp(cmd), async (msg) => {
        if (shouldIgnoreMessage(msg)) return;
        
        if (!Roles.isOwner(msg.from.id) && !Roles.isHighOwner(msg.from.id)) {
            return sendAccessDenied(msg.chat.id, msg.from.username);
        }
        
        const target = await getTarget(msg);
        if (!target) return bot.sendMessage(msg.chat.id, "❌ Tag atau reply pengguna!");
        
        switch(cmd) {
            case '/ban':
                bot.banChatMember(msg.chat.id, target.id);
                bot.sendMessage(msg.chat.id, `⛔ @${target.username} dibanned.`);
                break;
                
            case '/unban':
                bot.unbanChatMember(msg.chat.id, target.id);
                bot.sendMessage(msg.chat.id, `(⸙) @${target.username} unban.`);
                break;
                
            case '/mute':
                bot.restrictChatMember(msg.chat.id, target.id, { can_send_messages: false });
                bot.sendMessage(msg.chat.id, `(⸙) @${target.username} mute.`);
                break;
                
            case '/unmute':
                bot.restrictChatMember(msg.chat.id, target.id, {
                    can_send_messages: true,
                    can_send_media_messages: true,
                    can_send_other_messages: true,
                });
                bot.sendMessage(msg.chat.id, `(⸙) @${target.username} unmute.`);
                break;
                
            case '/open':
                bot.setChatPermissions(msg.chat.id, {
                    can_send_messages: true,
                    can_send_media_messages: true,
                    can_send_other_messages: true,
                    can_add_web_page_previews: true
                });
                bot.sendMessage(msg.chat.id, "🔓 *Grup telah dibuka!*", { parse_mode: "Markdown" });
                break;
                
            case '/close':
                bot.setChatPermissions(msg.chat.id, { can_send_messages: false });
                bot.sendMessage(msg.chat.id, "🔒 *Grup berhasil ditutup!*", { parse_mode: "Markdown" });
                break;
        }
    });
});

bot.onText(/\/myroles/, async (msg) => {
    if (shouldIgnoreMessage(msg)) return;
    
    const target = await getTarget(msg);
    if (!target) return bot.sendMessage(msg.chat.id, "❌ Tag atau reply pengguna!");
    
    try {
        const profile = await bot.getUserProfilePhotos(target.id, { limit: 1 });
        const userRole = Roles.getUserRole(target.id);
        
        const caption = `\`\`\`
👤 USER INFO\`\`\`
ID: \`${target.id}\`
Username: @${target.username || "-"}
Nama: ${target.first_name || "-"}
Role: ${userRole}
DC ID: ${target.dc_id || "-"}`;
        
        if (profile.total_count > 0) {
            bot.sendPhoto(msg.chat.id, profile.photos[0][0].file_id, { 
                caption, 
                parse_mode: "Markdown" 
            });
        } else {
            bot.sendMessage(msg.chat.id, caption, { parse_mode: "Markdown" });
        }
    } catch (error) {
        bot.sendMessage(msg.chat.id, "❌ Gagal mendapatkan info pengguna!");
    }
});

bot.onText(/^\/bokep(?:@[\w_]+)? (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const text = match[1];
  const userId = msg.from.id;
  
  try {
    const loadingMsg = await bot.sendMessage(
      chatId,
      `⏳ Mencari video...\n🔍 Kata kunci: ${text}`,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );

    const editMessage = async (newText) => {
      try {
        await bot.editMessageText(newText, {
          chat_id: chatId,
          message_id: loadingMsg.message_id,
          parse_mode: "Markdown",
        });
      } catch (err) {
        console.log("⚠️ Gagal edit pesan:", err.message);
      }
    };

    await editMessage(`🔍 *Mencari video...*\nKata kunci : ${text}`);
    const res = await fetch(
      `https://restapi-v2.simplebot.my.id/search/xnxx?q=${encodeURIComponent(text)}`
    );

    if (!res.ok) throw new Error(`Gagal ambil data pencarian (${res.status})`);
    const data = await res.json().catch(() => ({}));

    if (!data.status || !Array.isArray(data.result) || !data.result.length) {
      return editMessage(`⚠️ Tidak ada hasil ditemukan untuk: ${text}`);
    }

    const top = data.result[0];
    const title = top.title || text;
    const link = top.link;

    await editMessage(`⌛ Mengambil detail video...\n⎙ Judul : ${title}`);

    const dlRes = await fetch(
      `https://restapi-v2.simplebot.my.id/download/xnxx?url=${encodeURIComponent(link)}`
    );
    if (!dlRes.ok) throw new Error(`Gagal ambil detail (${dlRes.status})`);
    const dlData = await dlRes.json().catch(() => ({}));

    const high = dlData?.result?.files?.high;
    if (!high) {
      return editMessage(`⚠️ Video tidak memiliki kualitas High (HD)\n⎙ Judul : ${title}`);
    }

    await editMessage(`⌭ Mengunduh video...\n⎋ Resolusi : High`);

    const videoRes = await fetch(high);
    if (!videoRes.ok) throw new Error(`Gagal unduh file video (${videoRes.status})`);
    const buffer = Buffer.from(await videoRes.arrayBuffer());

    const filePath = path.join(process.cwd(), `temp_${Date.now()}.mp4`);
    fs.writeFileSync(filePath, buffer);

    await editMessage(`✅ Video ditemukan!\n⸙ Mengirim ke chat...`);
    await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

    await bot.sendVideo(chatId, filePath, {
      caption: `
\`\`\`
🎬 HASIL VIDEO BOKEP
⎙ Judul : ${title}
⎋ Resolusi : High
\`\`\`
`,
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      supports_streaming: true,
    });

    fs.unlinkSync(filePath);
  } catch (e) {
    console.error("❌ Error /bokep:", e);
    await bot.sendMessage(
      chatId,
      `❌ Terjadi kesalahan saat mengambil data\n\n\`\`\`${e.message}\`\`\``,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }
});

bot.onText(/^\/bokep(?:@[\w_]+)?$/, (msg) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const userId = msg.from.id;
  
  bot.sendMessage(chatId, `🪧 Gunakan: /bokep <kata kunci>`, {
    reply_to_message_id: msg.message_id,
  });
});

bot.onText(/^\/ssip(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const input = match[1];
  const senderId = msg.from.id;
  const userId = msg.from.id;
    
  if (!input) {
    return bot.sendMessage(chatId,
      "🪧 Format salah.\n\nContoh:\n`/ssip Name | 21:45 | 77 | TELKOMSEL`",
      { parse_mode: "Markdown" }
    );
  }

  const parts = input.split("|").map(p => p.trim());
  const text = parts[0];
  const time = parts[1] || "00:00";
  const battery = parts[2] || "100";
  const carrier = parts[3] || "TELKOMSEL";

  const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&messageText=${encodeURIComponent(text)}&carrierName=${encodeURIComponent(carrier)}&batteryPercentage=${encodeURIComponent(battery)}&signalStrength=4&emojiStyle=apple`;

  try {
    await bot.sendChatAction(chatId, "upload_photo");

    const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
    const buffer = Buffer.from(response.data, "binary");

    await bot.sendPhoto(chatId, buffer, {
      caption: `\`\`\`
「 ⚆ 」IPhone Generate\`\`\`
Chat : \`${text}\`
Time : ${time}
Baterry : ${battery}%
Kartu : ${carrier}
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 αµƭɦσɾ 」", url: "https://t.me/Popyeyeye" }],
          [{ text: "「 σωɳεɾ 」", url: "https://t.me/zayOwL7" }]
        ]
      }
    });
  } catch (err) {
    console.error(err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memproses gambar.");
  }
});

const MEK_TOKEN = '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';
const GITHUB_STORAGE = 'dirgaxnx/Upload';
const BRANCH = 'main';

bot.onText(/\/uploadgithub/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const userId = msg.from.id;
    
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '🪧 Reply ke gambar/video dengan /uploadgithub');
    }

    const repliedMsg = msg.reply_to_message;
    
    if (!repliedMsg.photo && !repliedMsg.video) {
        return bot.sendMessage(chatId, 'Reply ke gambar atau video');
    }

    try {
        await bot.sendMessage(chatId, 'Uploading...');

        let fileId, mimeType;

        if (repliedMsg.photo) {
            fileId = repliedMsg.photo[repliedMsg.photo.length - 1].file_id;
            
            mimeType = 'image/jpeg'; 
        } else {
            fileId = repliedMsg.video.file_id;
            mimeType = 'video/mp4'; 
        }
        
        const fileExtension = mimeType.includes('image') ? 'jpg' : 'mp4';
        const fileName = `${mimeType.includes('image') ? 'photo' : 'video'}_${Date.now()}.${fileExtension}`;


        const fileInfo = await bot.getFile(fileId);
        const fileUrl = `https://api.telegram.org/file/bot${CONFIG.botToken}/${fileInfo.file_path}`; 
        
        const response = await axios.get(fileUrl, { 
            responseType: 'arraybuffer' 
        });
        
        const fileBuffer = Buffer.from(response.data);

        const contentBase64 = fileBuffer.toString('base64');
        
        const githubResponse = await axios.put(
            `https://api.github.com/repos/${GITHUB_STORAGE}/contents/${fileName}`,
            {
                message: `Upload ${fileName} via Telegram Bot`,
                content: contentBase64,
                branch: BRANCH
            },
            {
                headers: {
                    'Authorization': `token ${MEK_TOKEN}`,
                    'Content-Type': 'application/json',
                    'Accept': 'application/vnd.github.v3+json'
                }
            }
        );

        const downloadUrl = githubResponse.data.content.download_url;
        await bot.sendMessage(chatId, `🚀 Berhasil diunggah!\n\nURL: ${downloadUrl}`, {
            reply_to_message_id: repliedMsg.message_id
        });

    } catch (error) {
        console.error('GITHUB UPLOAD ERROR:', error.response?.data || error.message);
        
        let errorMsg = 'Upload gagal. ';
        
        if (error.response?.status === 401) {
            errorMsg += 'Token GitHub salah atau tidak memiliki izin tulis (401 Unauthorized).';
        } else if (error.response?.status === 404) {
            errorMsg += 'Repositori tidak ditemukan (404 Not Found) atau nama branch salah.';
        } else if (error.response?.status === 422) {
             errorMsg += 'Kesalahan pemrosesan (422 Unprocessable Entity). Mungkin file terlalu besar atau format Base64 salah.';
        } else {
            errorMsg += 'Terjadi kesalahan tidak terduga. Cek konsol server.';
        }
        
        await bot.sendMessage(chatId, errorMsg);
    }
});

bot.onText(/^\/tiktoksearch (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const userId = msg.from.id;
  const keyword = match[1].trim();

  if (!keyword) {
    return bot.sendMessage(
      chatId,
      "🪧 Masukkan kata kunci!\nContoh: `/tiktoksearch zoro edit`",
      { parse_mode: "Markdown" }
    );
  }

  const loading = await bot.sendMessage(chatId, "⸙ SEARCHING VIDEO TIKTOK......");

  try {
    const searchUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(keyword)}&count=5`;
    const res = await axios.get(searchUrl, { timeout: 20000 });
    const data = res.data;

    const videos =
      data.data?.videos ||
      data.data?.list ||
      data.data?.aweme_list ||
      data.data ||
      [];

    if (!Array.isArray(videos) || videos.length === 0) {
      await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
      return bot.sendMessage(chatId, "⚠️ Tidak ada hasil ditemukan untuk kata kunci tersebut.");
    }

    const topVideos = videos.slice(0, 5);

    const uniqueKey = Math.random().toString(36).substring(2, 10);
    tiktokCache.set(uniqueKey, topVideos);

    const keyboard = topVideos.map((v, i) => {
      const title = (v.title || "Tanpa Judul").slice(0, 35);
      return [
        { text: `${i + 1}. ${title}`, callback_data: `tiktok|${uniqueKey}|${i}` },
      ];
    });

    await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
    await bot.sendMessage(
      chatId,
      `⸙ Ditemukan *${topVideos.length}* hasil untuk:\n\`${keyword}\`\nPilih salah satu video di bawah ini:`,
      {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard },
      }
    );
  } catch (err) {
    console.error("❌ TikTok Search Error:", err.message);
    await bot.deleteMessage(chatId, loading.message_id).catch(() => {});
    bot.sendMessage(chatId, "⚠️ Gagal mengambil hasil pencarian TikTok.");
  }
});
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (!data.startsWith("tiktok|")) return;

  await bot.answerCallbackQuery(query.id, { text: "⏳ MENGUNDUH VIDEO SABAR LOADING....." });

  const [, cacheKey, indexStr] = data.split("|");
  const index = parseInt(indexStr, 10);

  const cached = tiktokCache.get(cacheKey);
  if (!cached || !cached[index]) {
    return bot.sendMessage(chatId, "⚠️ Data video tidak ditemukan (cache kedaluwarsa).");
  }

  const v = cached[index];
  const author =
    v.author?.unique_id || v.author?.nickname || v.user?.unique_id || "unknown";
  const videoId = v.video_id || v.id || v.aweme_id || v.short_id || v.video?.id;
  const tiktokUrl = `https://www.tiktok.com/@${author}/video/${videoId}`;

  try {
    const res = await axios.post(
      "https://www.tikwm.com/api/",
      `url=${encodeURIComponent(tiktokUrl)}`,
      {
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        timeout: 30000,
      }
    );

    const result = res.data;
    if (!result || result.code !== 0 || !result.data) {
      throw new Error("Video tidak valid.");
    }

    const vid = result.data;
    const videoUrl = vid.play || vid.hdplay || vid.wmplay || vid.play_addr;

    const caption = `\`\`\`
☀ Lolipop Searching\`\`\`
Video : *${vid.title || "Video TikTok"}*
Author : @${vid.author?.unique_id || "unknown"}
Likes : ${vid.digg_count || 0} 
Comment : ${vid.comment_count || 0}
[🌐 Lihat di TikTok](${tiktokUrl})`;

    await bot.sendVideo(chatId, videoUrl, {
      caption,
      parse_mode: "Markdown",
    });

  } catch (err) {
    console.error("❌ Gagal download:", err.message);
    bot.sendMessage(chatId, "⚠️ Gagal mengunduh video TikTok.");
  }
});

bot.onText(/^\/tiktokdl(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const userId = msg.from.id;
  const args = match[1]?.trim();
    
  if (!args)
    return bot.sendMessage(
      chatId,
      "🪧 Format: /tiktokdl https://example.com/"
    );

  let url = args;

  if (msg.entities) {
    for (const e of msg.entities) {
      if (e.type === "url") {
        url = msg.text.substring(e.offset, e.offset + e.length);
        break;
      }
    }
  }

  const wait = await bot.sendMessage(chatId, "Memproses Pastikan Jaringan Anda Bagus...");

  try {
    const { data } = await axios.get("https://tikwm.com/api/", {
      params: { url },
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36",
        "accept": "application/json,text/plain,*/*",
        "referer": "https://tikwm.com/"
      },
      timeout: 20000
    });

    if (!data || data.code !== 0 || !data.data)
      return bot.sendMessage(chatId, "❌ ☇ Gagal ambil data video, pastikan link valid");

    const d = data.data;

    if (Array.isArray(d.images) && d.images.length) {
      const imgs = d.images.slice(0, 10);
      const media = [];

      for (const img of imgs) {
        const res = await axios.get(img, { responseType: "arraybuffer" });
        media.push({
          type: "photo",
          media: { source: Buffer.from(res.data) }
        });
      }

      await bot.sendMediaGroup(chatId, media);
      return;
    }

    const videoUrl = d.play || d.hdplay || d.wmplay;
    if (!videoUrl)
      return bot.sendMessage(chatId, "❌ ☇ Tidak ada link video yang bisa diunduh");

    const video = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36"
      },
      timeout: 30000
    });

    await bot.sendVideo(
      chatId,
      Buffer.from(video.data),
      { supports_streaming: true },
      { filename: `${d.id || Date.now()}.mp4` }
    );
  } catch (e) {
    const errMsg = e?.response?.status
      ? `❌ ☇ Error ${e.response.status} saat mengunduh video`
      : "❌ ☇ Gagal mengunduh, koneksi lambat atau link salah";
    await bot.sendMessage(chatId, errMsg);
  } finally {
    try {
      await bot.deleteMessage(chatId, wait.message_id);
    } catch {}
  }
});

bot.onText(/^\/ipinfo(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const userId = msg.from.id;
  const ip = match && match[1] ? match[1].trim() : null;
  
  if (!ip) {
    return bot.sendMessage(chatId, "🪧 Format: /ipinfo 8.8.8.8");
  }

  function isValidIPv4(ip) {
    const parts = ip.split(".");
    if (parts.length !== 4) return false;
    return parts.every(p => {
      if (!/^\d{1,3}$/.test(p)) return false;
      if (p.length > 1 && p.startsWith("0")) return false;
      const n = Number(p);
      return n >= 0 && n <= 255;
    });
  }

  function isValidIPv6(ip) {
    const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::)|(::[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::([0-9a-fA-F]{1,4}){0,6}))$/;
    return ipv6Regex.test(ip);
  }

  if (!isValidIPv4(ip) && !isValidIPv6(ip)) {
    return bot.sendMessage(chatId, "❌ ☇ IP tidak valid. Masukkan IPv4 (contoh: 8.8.8.8) atau IPv6 yang benar.");
  }

  let processingMsg = await bot.sendMessage(chatId, `🔎 ☇ Tracking IP ${ip} — sedang memproses...`);

  try {
    const steps = [
      { p: 10, text: "MENYIAPKAN KONEKSI SERVER..." },
      { p: 30, text: "MENGAMBIL DATA IP..." },
      { p: 50, text: "MENGANALISIS LOKASI IP..." },
      { p: 75, text: "MENYUSUN HASIL AKHIR..." },
      { p: 100, text: "SELESAI BY LOLIPOP" },
    ];

    for (const step of steps) {
      await new Promise(r => setTimeout(r, 400 + Math.random() * 300));
      await bot.editMessageText(
        `🔎 ☇ Tracking IP ${ip}\n${step.p}% ${step.text}`,
        { chat_id: chatId, message_id: processingMsg.message_id }
      ).catch(() => {});
    }

    const res = await axios.get(`https://ipwhois.app/json/${encodeURIComponent(ip)}`, { timeout: 10000 });
    const data = res.data;

    if (!data || data.success === false) {
      return bot.editMessageText(`❌ ☇ Gagal mendapatkan data untuk IP: ${ip}`, {
        chat_id: chatId,
        message_id: processingMsg.message_id,
      });
    }

    const lat = data.latitude || "";
    const lon = data.longitude || "";
    const mapsUrl = lat && lon ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lat + "," + lon)}` : null;

    const caption = `\`\`\`
⬡═―—⊱ ⎧ FlowX Infinite ⎭ ⊰―—═⬡\`\`\`
⌑ IP: ${data.ip || "-"}
⌑ Country: ${data.country || "-"} ${data.country_code ? `(${data.country_code})` : ""}
⌑ Region: ${data.region || "-"}
⌑ City: ${data.city || "-"}
⌑ ZIP: ${data.postal || "-"}
⌑ Timezone: ${data.timezone_gmt || "-"}
⌑ ISP: ${data.isp || "-"}
⌑ Org: ${data.org || "-"}
⌑ ASN: ${data.asn || "-"}
⌑ Lat/Lon: ${lat || "-"}, ${lon || "-"}
`.trim();

    const options = {
      parse_mode: "Markdown",
      reply_markup: mapsUrl
        ? {
            inline_keyboard: [
              [{ text: "⌜ Lokasi ⌟ ☇ 𝖧𝖾𝗋𝖾", url: mapsUrl }]
            ]
          }
        : undefined,
    };

    await bot.editMessageText(caption, {
      chat_id: chatId,
      message_id: processingMsg.message_id,
      ...options,
    }).catch(async () => {
      await bot.sendMessage(chatId, caption, options);
    });

  } catch (err) {
    console.error("TrackIP Error:", err);
    await bot.editMessageText(
      "❌ ☇ Terjadi kesalahan saat mengambil data IP (timeout atau API tidak merespon). Coba lagi nanti.",
      { chat_id: chatId, message_id: processingMsg.message_id }
    ).catch(async () => {
      await bot.sendMessage(chatId, "❌ ☇ Terjadi kesalahan saat mengambil data IP.");
    });
  }
});

const aiUsers = new Set();

bot.onText(/^\/chatai(?:@[\w_]+)?(?: (.*))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const userId = msg.from.id;
  
    aiUsers.add(userId);

    let prompt = match[1]?.trim();
    const reply = msg.reply_to_message;

    if (!prompt && reply && reply.from.id === bot.botInfo.id) {
        prompt = reply.text;
    }

    if (reply) {
        if (reply.text) {
            prompt = `Perbaiki atau lanjutkan teks berikut:\n\n${reply.text}`;
        }

        if (reply.document) {
            const file = await bot.getFile(reply.document.file_id);
            const fileUrl = `https://api.telegram.org/file/bot${CONFIG.botToken}/${file.file_path}`;
            prompt = `Perbaiki FILE berikut:\n${fileUrl}`;
        }

        if (reply.photo) {
            const photo = reply.photo[reply.photo.length - 1];
            const file = await bot.getFile(photo.file_id);
            const fileUrl = `https://api.telegram.org/file/bot${CONFIG.botToken}/${file.file_path}`;
            prompt = `Perbaiki kualitas foto berikut dan kirimkan hasilnya:\n${fileUrl}`;
        }
    }

    if (!prompt) {
        return bot.sendMessage(chatId, "🪧 Format salah.\nGunakan `/chatai <teks>` atau reply teks/foto.", {
            parse_mode: "Markdown"
        });
    }

    const waitMsg = await bot.sendMessage(chatId, "⏳ AI sedang memproses...");

    try {
        const apiURL = `https://api.ootaizumi.web.id/ai/copilot?prompt=${encodeURIComponent(prompt)}`;
        const res = await fetch(apiURL);
        const data = await res.json();

        const aiText = data.result?.text || data.result || "";

        const fileRegex = /FILE:\s*(https?:\/\/\S+)/i;
        const fileMatch = aiText.match(fileRegex);

        if (fileMatch) {
            await bot.editMessageText("⸙ Mengirim file hasil AI...", {
                chat_id: chatId,
                message_id: waitMsg.message_id
            });

            return bot.sendDocument(chatId, fileMatch[1]);
        }

        const imgRegex = /IMAGE:\s*(https?:\/\/\S+)/i;
        const imgMatch = aiText.match(imgRegex);

        if (imgMatch) {
            await bot.editMessageText("⸙ Mengirim gambar hasil AI...", {
                chat_id: chatId,
                message_id: waitMsg.message_id
            });

            return bot.sendPhoto(chatId, imgMatch[1]);
        }

        await bot.editMessageText(aiText, {
            chat_id: chatId,
            message_id: waitMsg.message_id
        });

    } catch (err) {
        console.error(err);
        await bot.editMessageText("❌ Terjadi kesalahan. Silakan coba lagi.", {
            chat_id: chatId,
            message_id: waitMsg.message_id
        });
    }
});

function initializeFirstHighOwner() {
    if (data.highowner.highowners.length === 0) {
        console.log("⚠️ Tidak ada HIGH OWNER yang terdaftar!");
        console.log("⚠️ Silakan tambahkan HIGH OWNER pertama secara manual:");
        console.log("1. Buka file: ☇ Confidential/highowner.json");
        console.log("2. Tambahkan ID Telegram Anda: { \"highowners\": [YOUR_ID_HERE] }");
    } else {
        console.log(`✅ HIGH OWNER terdaftar: ${data.highowner.highowners.length} user`);
    }
}

initializeFirstHighOwner();
console.log("MD INVISO BOT — AKTIF!");
console.log("Data tersimpan di: ☇ Confidential/");